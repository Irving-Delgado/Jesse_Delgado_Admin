package com.isaacsuntag.admindash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginRegApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginRegApplication.class, args);
	}
}
